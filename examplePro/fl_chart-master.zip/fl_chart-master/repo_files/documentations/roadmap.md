## Roadmap


- [x] Add Interactivity

- [ ] Add Animations

- [ ] Add ScatterPlot chart

- [ ] Add HeatMap Chart [see more](https://altair-viz.github.io/gallery/simple_heatmap.html)

- [ ] Composability

- [ ] Add Zoom feature

- [ ] Add stacked column chart (on our BarChart)

let me know your suggestions to add here