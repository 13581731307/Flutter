import 'package:flutter/material.dart';
import './my_main_app.dart';

void main() => runApp(MyMainApp());
