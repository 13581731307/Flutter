## [0.1.0] - 2018-08-30

* **Breaking change**. Adjusted Flutter SDK constraint to match beta (0.6.0).

## [0.0.3] - 2018-05-09

* Added `edgeStyle` property and `SegmentEdgeStyle` enum used to determine the
  strokeCap drawn for a chart's segments.

## [0.0.2] - 2018-03-21

* Added `holeLabel` and `labelStyle` properties used to draw a label
  in the center of the radial chart.

## [0.0.1] - 2017-11-03

* Animated pie and radial charts.
