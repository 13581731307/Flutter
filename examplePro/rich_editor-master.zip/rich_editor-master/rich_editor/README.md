# rich_editor

Rich editor for flutter platform

## Getting Started

For help getting started with Flutter, view our online [documentation](http://flutter.io/).

For help on editing package code, view the [documentation](https://flutter.io/developing-packages/).
