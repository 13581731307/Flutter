# rich_editor_demo

Demo app for the rich editor.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
