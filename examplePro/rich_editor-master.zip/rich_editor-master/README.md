# rich_editor
This is an RichEditor for the Flutter platform.
Demo App:
https://play.google.com/store/apps/details?id=eu.long1.richeditordemo
