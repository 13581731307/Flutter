## LAUNCH MINI-PROGRAM
`Fluwx` 现在可以拉起小程序了.
```dart
import 'package:fluwx/fluwx.dart' as fluwx;
fluwx.launchMiniProgram(
                username: "gh_d43f693ca31f"
              );

```