## LAUNCH MINI-PROGRAM
`Fluwx` can launch mini-program now.
```dart
import 'package:fluwx/fluwx.dart' as fluwx;
fluwx.launchMiniProgram(
                username: "gh_d43f693ca31f"
              );

```