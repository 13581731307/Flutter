## 移动应用一次性订阅消息
查看[详情](https://open.weixin.qq.com/cgi-bin/showdocument?action=dir_list&t=resource/res_list&verify=1&id=open1500434436_aWfqW&token=&lang=zh_CN).
```dart
   import 'package:fluwx/fluwx.dart' as fluwx;
   fluwx.subscribeMsg(
      appId: "appId",
      scene: 1,
      templateId: "templateId",
      reserved: "reserved",
    );
```