#import <Flutter/Flutter.h>
#import <UIKit/UIKit.h>
#import "FluwxShareHandler.h"

@interface AppDelegate : FlutterAppDelegate

@end
//com.tencent.wc.xin.SDKSample
//com.jarvanmo.fluwx-example
