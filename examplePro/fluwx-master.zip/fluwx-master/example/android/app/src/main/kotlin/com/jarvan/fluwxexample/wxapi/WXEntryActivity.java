package com.jarvan.fluwxexample.wxapi;

import android.os.Bundle;
import android.widget.Toast;

import com.jarvan.fluwx.wxapi.FluwxWXEntryActivity;

import org.jetbrains.annotations.Nullable;


public class WXEntryActivity extends FluwxWXEntryActivity {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}