package com.jarvan.fluwxexample.wxapi;

import com.jarvan.fluwx.wxapi.FluwxWXEntryActivity;

public class WXPayEntryActivity extends FluwxWXEntryActivity {


}
