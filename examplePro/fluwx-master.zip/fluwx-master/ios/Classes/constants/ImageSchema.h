//
// Created by mo on 2018/8/16.
//

#import <Foundation/Foundation.h>


extern NSString *const SCHEMA_ASSETS;
extern NSString *const SCHMEA_HTTP;
extern NSString *const SCHMEA_HTTPS;
extern NSString *const SCHEMA_FILE;

@interface ImageSchema : NSObject
@end