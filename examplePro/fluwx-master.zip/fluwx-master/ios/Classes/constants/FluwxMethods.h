//
// Created by mo on 2018/8/15.
//

#import <Foundation/Foundation.h>

extern NSString *const registerApp;
extern NSString *const unregisterApp;
extern NSString *const weChatResponse;
extern NSString *const shareText;
extern NSString *const shareImage;
extern NSString *const shareMusic;
extern NSString *const shareVideo;
extern NSString *const shareWebPage;
extern NSString *const shareMiniProgram;
extern NSString *const launchMiniProgram;

@interface FluwxMethods : NSObject
@end