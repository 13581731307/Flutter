//
// Created by mo on 2018/8/16.
//

#import "ImageSchema.h"

NSString *const SCHEMA_ASSETS = @ "assets://";
NSString *const SCHMEA_HTTP = @"http://";
NSString *const SCHMEA_HTTPS = @"https://";
NSString *const SCHEMA_FILE = @"file://";

@implementation ImageSchema
@end