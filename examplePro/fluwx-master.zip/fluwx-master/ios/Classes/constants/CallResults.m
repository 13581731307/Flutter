//
// Created by mo on 2018/8/15.
//

#import "CallResults.h"

NSString *const resultDone = @"done";
NSString *const resultErrorNeedWeChat = @"wxapi not configured";
NSString *const resultMessageNeedWeChat = @"please config  wxapi first";
@implementation CallResults {

}
@end