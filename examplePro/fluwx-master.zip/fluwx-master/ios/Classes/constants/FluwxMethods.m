//
// Created by mo on 2018/8/15.
//

#import "FluwxMethods.h"

NSString *const registerApp = @"registerApp";
NSString *const unregisterApp = @"unregisterApp";
NSString *const weChatResponse = @"onWeChatResponse";
NSString *const shareText = @"shareText";
NSString *const shareImage = @"shareImage";
NSString *const shareMusic = @"shareMusic";
NSString *const shareVideo = @"shareVideo";
NSString *const shareWebPage = @"shareWebPage";
NSString *const shareMiniProgram = @"shareMiniProgram";
NSString *const LaunchMiniProgram = @"launchMiniProgram";
@implementation FluwxMethods {


}
@end