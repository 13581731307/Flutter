//
// Created by mo on 2018/8/15.
//

#import <Foundation/Foundation.h>

extern NSString *const resultDone;
extern NSString *const resultErrorNeedWeChat;
extern NSString *const resultMessageNeedWeChat;
@interface CallResults : NSObject
@end