## 1.1.0+1
* 兼容swift

## 1.1.0
* 升级sdk，同时ios源换成官方源

## 1.0.0+1
* 按照pub意见进行修改

## 1.0.0

* ios不必重写AppDelegate

## 0.1.6+2
* 按照pub意见进行修改

## 0.1.6+1
* 按照pub意见进行修改

## 0.1.6
* 支付宝SDK升级到15.6.4
* 升级Kotlin

## 0.1.5
* 支持检查客户端是否安装了支付宝App。

## 0.1.4
* Fix #18

## 0.1.3
* Android支持沙箱了


## 0.1.2
* 修复在ios上调用登录报错的问题

## 0.1.1
* 修复ios上通过webview登录无回调的问题

## 0.1.0
* 支持支付宝登录了。

## 0.0.8
* kotlin升级至1.3.21
* kotlinx-coroutines升级至1.1.1
* AliPaySDK升级至15.6.0

## 0.0.7
* android构建工具升级
* AliPaySDK升级至15.5.9

## 0.0.6
* android构建工具升级
* AliPaySDK升级至15.5.7

## 0.0.5
* *build.gradle*升级到了*3.2.0*
* *kotlin*升级到了*1.2.71*

## 0.0.4
* 修复iOS无回调问题

## 0.0.3
* 删除AliPayModel

## 0.0.2
* 修复iOS支付bug

## 0.0.1

* first released.
