#import <Flutter/Flutter.h>


@interface TobiasPlugin : NSObject<FlutterPlugin>
+(BOOL)handleOpenURL:(NSURL*)url;
@end
