## 1.1.0
* Added Initial page attribute. [cda6de80113502f17da8085d95c5eaea543f42b7](https://github.com/iamSahdeep/liquid_swipe_flutter/commit/cda6de80113502f17da8085d95c5eaea543f42b7)
* Added Slide Icon on pages. [32680cdc4571a705b4e7f11467b450e37016807d](https://github.com/iamSahdeep/liquid_swipe_flutter/commit/32680cdc4571a705b4e7f11467b450e37016807d)
* Other Minor Fixes. [52d159403525261dbfaa99a52af718a1ddc8274f](https://github.com/iamSahdeep/liquid_swipe_flutter/commit/52d159403525261dbfaa99a52af718a1ddc8274f) 
## 1.0.2

* Minor spell changes

## 1.0.1

* Initialized

