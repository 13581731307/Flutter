#import <Flutter/Flutter.h>

@interface LiquidSwipePlugin : NSObject<FlutterPlugin>
@end
