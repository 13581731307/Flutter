## 0.3.0

- dart 2.0+ & Flutter 0.11.8
- fix ios error #10 

## 0.2.0+
- use the device detected locale by default

## 0.1.0
- basic recognition