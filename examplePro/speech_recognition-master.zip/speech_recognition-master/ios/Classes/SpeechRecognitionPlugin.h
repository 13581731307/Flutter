#import <Flutter/Flutter.h>

@interface SpeechRecognitionPlugin : NSObject<FlutterPlugin>
@end
