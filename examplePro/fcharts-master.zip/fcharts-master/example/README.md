# fcharts_example

Demonstrates how to use the fcharts plugin.

See `lib/line` for example charts.