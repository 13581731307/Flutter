/// 4-tiered level system.
enum Level {
  Very,
  Quite,
  Kinda,
  Not,
}
