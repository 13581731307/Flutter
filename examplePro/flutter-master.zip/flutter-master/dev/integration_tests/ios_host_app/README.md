# iOS host app

iOS host app for a Flutter module created using
```
$ flutter create -t module hello
```
and placed in a sibling folder to (a clone of) the host app.
Used by the `module_test_ios.dart` device lab test.
