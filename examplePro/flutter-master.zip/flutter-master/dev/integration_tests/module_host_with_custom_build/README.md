# Android host app

Android host app for a Flutter module created using
```
$ flutter create -t module hello
```
and placed in a sibling folder to (a clone of) the host app.
Used by the `module_host_with_custom_build_test.dart` device lab test.
