/// [Flutter platform integration APIs for iOS.](https://docs.flutter.io/objcdoc/)
library iOS;
