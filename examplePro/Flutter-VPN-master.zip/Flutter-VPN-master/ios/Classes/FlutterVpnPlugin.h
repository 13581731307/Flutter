#import <Flutter/Flutter.h>

@interface FlutterVpnPlugin : NSObject<FlutterPlugin>
@end
