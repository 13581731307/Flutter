abstract class StreamBase {
  void dispose();
}
