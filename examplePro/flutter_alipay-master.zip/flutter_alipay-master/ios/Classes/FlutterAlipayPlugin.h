#import <Flutter/Flutter.h>

@interface FlutterAlipayPlugin : NSObject<FlutterPlugin>

+(BOOL)handleOpenURL:(NSURL*)url;

@end
